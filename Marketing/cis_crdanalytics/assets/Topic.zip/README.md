# BottleAppAzure [![Deploy to Azure](http://azuredeploy.net/deploybutton.png)](https://azuredeploy.net/)

Bottle is a fast, simple and lightweight WSGI micro web-framework for Python. It is distributed as a single file module and has no dependencies other than the Python Standard Library.
- [Get Started](http://bottlepy.org/docs/dev/index.html)
- [Development blog](http://blog.bottlepy.org/)
