﻿1. Publish the web site follow the following instruction http://www.c-sharpcorner.com/uploadfile/francissvk/how-to-publish-asp-net-web-application-using-visual-studio-2/
2. Copy the setup.ps1 script out from Deploy folder in website root to the same level with the website root folder
3. Check the folder name is the same as the packagename defined in the script. 
4. Copy the sameple database package to the the same level with the website root folder